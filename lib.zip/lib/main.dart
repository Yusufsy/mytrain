import 'package:flutter/material.dart';
import 'package:mytrain/loginpage.dart';
import 'package:mytrain/homepage.dart';
import 'package:mytrain/models/user.dart';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        
        colorScheme: .fromSeed(seedColor: Colors.deepPurple),
      ),
      home: MyHomePage(user: User(id: '1', fullname: 'Yusuf', email: "yusuf@mail.com", password: "")),
      // const LoginPage(),
    );
  }
}

