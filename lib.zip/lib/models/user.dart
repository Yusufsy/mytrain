class User{
  String id;
  String? fullname;
  String? email;
  String? password;

  User({required this.id, this.fullname, this.email, this.password});
}