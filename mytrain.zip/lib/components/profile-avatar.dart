import 'package:flutter/material.dart';

class ProfileAvatar extends StatelessWidget {
  const ProfileAvatar({super.key});

  @override
  Widget build(BuildContext context) {
    return 
    Center(child: CircleAvatar(
      radius: 200,
      backgroundImage: AssetImage('assets/images/train-app-logo.png'),
    ));
  }
}