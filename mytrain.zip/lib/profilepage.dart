import 'package:flutter/material.dart';
import 'package:mytrain/components/profile-avatar.dart';
import 'package:url_launcher/url_launcher.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            ProfileAvatar(),
            SizedBox(height: 20),
            ListTile(title: Text('Edit Profile'), leading: Icon(Icons.edit)),
            ListTile(title: Text('Change Password'), leading: Icon(Icons.lock)),
            ListTile(
              title: Text('Terms and Conditions'),
              leading: Icon(Icons.description),
              onTap: () async {
                // Handle terms and conditions tap
                await launchUrl(Uri.parse('https://www.termsfeed.com/blog/sample-terms-and-conditions-template/'));
              },
            ),
            ListTile(title: Text('Contact Us'), leading: Icon(Icons.message),
            onTap: () async {
              // launch whatsapp with prefilled message
              final Uri whatsappUrl = Uri.parse('https://wa.me/2348134567890?text=Hello%20MyTrain%20Support%20Team');
              await launchUrl(whatsappUrl);
            },),
            ListTile(title: Text('Logout'), leading: Icon(Icons.logout)),
            Opacity(
              opacity: 0.3,
              child: ListTile(
                title: Text('Delete Account'),
                leading: Icon(Icons.delete),
                onLongPress: () async {
                  // Handle delete account action
                  print('Delete account action triggered');

                  await showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Confirm Delete Account'),
                        content: Text(
                            'Are you sure you want to delete your account? This action cannot be undone.'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Cancel'),
                          ),
                          TextButton(
                            onPressed: () {
                              // Perform delete account action here
                              print('Account deleted');
                              Navigator.of(context).pop();
                            },
                            child: Text('Delete', style: TextStyle(color: Colors.red)),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
